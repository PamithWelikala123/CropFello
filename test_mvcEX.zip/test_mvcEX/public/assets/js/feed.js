function openForm() {
    document.getElementById("myForm").style.display = "block";
    document.getElementById("myForm").style.visibility = "visible";
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}