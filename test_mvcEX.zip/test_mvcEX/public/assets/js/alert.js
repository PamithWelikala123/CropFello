function aler($message) {
    alert($message);
  }