<?php 

if($_SERVER['SERVER_NAME'] == 'localhost'){

    define('DBNAME','data_pra');
    define('DBHOST','localhost');
    define('DBUSER','root');
    define('DBPASS','');
    define('DBDRIVER','');

    define('ROOT', 'http://localhost/test_mvcEX/public');

}else{
    define('ROOT', 'https://www.mywebsite.com');
}

define('APP_NAME', "CropFello");
define('APP_DESC', "It is all about crops");

define('DEBUG',true);