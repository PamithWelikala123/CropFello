<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require __DIR__.'/vendor/autoload.php';

function show($stuff){
    echo "<pre>";
    print_r($stuff);
    echo "</pre>";
}

function esc($str){
    return htmlspecialchars($str);
}

function redirect($path){
    header("Location: " . ROOT."/".$path);
    die;
}

function ban_email($get_email)
{

    $mail = new PHPMailer(TRUE);
    $mail->isSMTP();
    $mail->Mailer = "smtp";

    $mail->SMTPDebug = 0; //Enable verbose debug output                                          //Send using SMTP
    $mail->Host = 'smtp.gmail.com'; //Set the SMTP server to send through
    $mail->SMTPAuth = true; //Enable SMTP authentication
    $mail->Username = 'cropfello@gmail.com'; //SMTP username
    $mail->Password = 'wugqelupsgutlapd'; //SMTP password
    $mail->SMTPSecure = 'tls'; //Enable implicit TLS encryption
    $mail->Port = 587;

    try {

        $mail->setFrom("cropfello@gmail.com");

        $mail->addAddress($get_email);

        $mail->Subject = "Banned from Cropfello";

        $mail->Body = "You are banned from CropFello";

        if (!$mail->send()) {
            return false;
        } else {
            return true;
        }
    } catch (Exception $e) {
        // echo $e->errorMessage();
        return false;
    } catch (\Exception $e) {
        // echo $e->getMessage();
        return false;

    }
}

function del_email($get_email)
{

    $mail = new PHPMailer(TRUE);
    $mail->isSMTP();
    $mail->Mailer = "smtp";

    $mail->SMTPDebug = 0; //Enable verbose debug output                                          //Send using SMTP
    $mail->Host = 'smtp.gmail.com'; //Set the SMTP server to send through
    $mail->SMTPAuth = true; //Enable SMTP authentication
    $mail->Username = 'cropfello@gmail.com'; //SMTP username
    $mail->Password = 'wugqelupsgutlapd'; //SMTP password
    $mail->SMTPSecure = 'tls'; //Enable implicit TLS encryption
    $mail->Port = 587;

    try {

        $mail->setFrom("cropfello@gmail.com");

        $mail->addAddress($get_email);

        $mail->Subject = "post Removed";

        $mail->Body = "Your post removed from the system feed";

        if (!$mail->send()) {
            return false;
        } else {
            return true;
        }
    } catch (Exception $e) {
        // echo $e->errorMessage();
        return false;
    } catch (\Exception $e) {
        // echo $e->getMessage();
        return false;

    }
}