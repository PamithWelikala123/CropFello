<!DOCTYPE html>
<html>
    <head>
        
        <title>
            login page
        </title>
        <link rel="Stylesheet" href="<?=ROOT?>/assets/css/nik.css">
    </head>
    <body>
                    <img class="logo"  src="<?=ROOT?>/assets/images/logo.png">
                    <div class="some">Admin Login</div>
                    <form method="post">

                        <?php if(!empty($errors)):?>
                            <div class="alert alert-danger">
                                <?= implode("<br>",$errors)?>
                            </div>
                        <?php endif;?>
                        <input class="search1" type="textbox" placeholder="  Email" name="Admin_ID">
                        <input class="search2" type="password" placeholder="  Password" name="password">
                        <input class="button" type="submit" value="Login">
                    </form>
                        
                    
    </body>

</html>