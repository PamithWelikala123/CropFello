<html>
    <head>
        <title>Feed</title><link rel="Stylesheet" href="<?=ROOT?>/assets/css/expired.css">
        <script src="<?=ROOT?>/assets/js/feed.js"></script>
    </head>
    <body>
    <div>
        <div class="p2">
            <div><img class="logo"  src="<?=ROOT?>/assets/images/logo.png"></div>
            <div><img class="line3"  src="<?=ROOT?>/assets/images/line3.png"></div>
            <div><img class="square"  src="<?=ROOT?>/assets/images/square.png"></div>
            <div><button class="feed">Feed</button></div>
            <div><img class="Seller1"  src="<?=ROOT?>/assets/images/Seller1.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/seller"> <input type="submit" class="seller" value="Seller"/></a>';?>
            <div><img class="truck"  src="<?=ROOT?>/assets/images/truck.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/deliverer"> <input type="submit" class="deliverer" value="Deliverer"/></a>';?>
        </div>
        
        <div class="p3">
        <!--div class="user"><?=$username?></div-->
            <div class="dropdown">
                <input type="image" class="img" src="<?=ROOT?>/assets/images/account.png">
                <div class="dropdown-content">
                    <a href="<?=ROOT?>/feed/register" style="text-align:center">Admin Registration</a>
                    <a href="<?=ROOT?>/feed/profile" style="text-align:center">My Profile</a>
                    <a style="text-align:center" class="log" onclick="openForm()">Logout</a>
                </div>
            </div>
        </div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed"> <input type="submit" class="mrp" value="MRP"/></a>';?>
            <div><button class="expired">Expired</button></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/soldout"> <input type="submit" class="soldout" value="Soldout"/></a>';?>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/stat"> <input type="submit" class="stat" value="Statistics"/></a>';?>
            <form method="post"><div class="post">Post List</div>
            <div class="postcode"><u>Post Code</div>
            <div class="postcode" style="left:720px"><u>Seller ID</div>
            <div class="postcode" style="left:920px">EXP</u></div>
            <div class="p1"><div class="p5">
    
            <?php foreach($data as $dat){ ?>
                <div><?php echo($dat->post_id);?></div>
                <div><?php echo($dat->seller_id);?></div>
                <div><?php echo($dat->exp);?></div>
                <div><?php echo '<button class="delete" name="send['.$dat->id.']/">Send</button>' ?></div>
                <div><?php echo '<button class="delete" name="btn['.$dat->id.']/">Delete Post</button>' ?></div>
            <?php }
            ?>
            
            </div></div>
        </form>

          

