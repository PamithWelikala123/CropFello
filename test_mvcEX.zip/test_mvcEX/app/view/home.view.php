<h1><?=$username?></h1>

<img src="<?=ROOT?>/assets/images/logo.png">

<a href="<?=ROOT?>/logout">Logout</a>