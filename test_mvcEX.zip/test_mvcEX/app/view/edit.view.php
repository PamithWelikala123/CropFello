<html>
    <head>
        <title>Feed</title><link rel="Stylesheet" href="<?=ROOT?>/assets/css/edit.css">
        <script src="<?=ROOT?>/assets/js/feed.js"></script>
    </head>
    <body>
    <div>
        <div class="p2">
            <div><img class="logo"  src="<?=ROOT?>/assets/images/logo.png"></div>
            <div><img class="line3"  src="<?=ROOT?>/assets/images/line3.png"></div>
            <div><img class="square"  src="<?=ROOT?>/assets/images/square.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed"> <input type="submit" class="feed" value="Feed"/></a>';?>
            <div><img class="Seller1"  src="<?=ROOT?>/assets/images/Seller1.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/seller"> <input type="submit" class="seller" value="Seller"/></a>';?>
            <div><img class="truck"  src="<?=ROOT?>/assets/images/truck.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/deliverer"> <input type="submit" class="deliverer" value="Deliverer"/></a>';?>
        </div>
        
        <div class="p3">
            <div class="user"><?=$username?></div>
            <div class="dropdown">
                <input type="image" class="img" src="<?=ROOT?>/assets/images/account.png">
                <div class="dropdown-content">
                    <a href="<?=ROOT?>/feed/register" style="text-align:center">Admin Registration</a>
                    <a href="<?=ROOT?>/feed/profile" style="text-align:center">My Profile</a>
                    <a style="text-align:center" class="log" onclick="openForm()">Logout</a>
                </div>
            </div>        
        </div>