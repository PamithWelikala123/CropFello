<html>
    <head><title>Feed</title><link rel="Stylesheet" href="<?=ROOT?>/assets/css/profile.css"></head>
    <body>
    <div>
        <div class="p2">
            <div><img class="logo"  src="<?=ROOT?>/assets/images/logo.png"></div>
            <div><img class="line3"  src="<?=ROOT?>/assets/images/line3.png"></div>
            <div><img class="square"  src="<?=ROOT?>/assets/images/square.png"></div>
            <!--div><button class="feed">Feed</button></div-->
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed"> <input type="submit" class="feed" value="Feed"/></a>';?>
            <div><img class="Seller1"  src="<?=ROOT?>/assets/images/Seller1.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/seller"> <input type="submit" class="seller" value="Seller"/></a>';?>
            <div><img class="truck"  src="<?=ROOT?>/assets/images/truck.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/deliverer"> <input type="submit" class="deliverer" value="Deliverer"/></a>';?>
        </div>
        
        <div class="p3">
            <div class="dropdown">
                <input type="image" class="img" src="<?=ROOT?>/assets/images/account.png">
                <div class="dropdown-content">
                    <a href="<?=ROOT?>/feed/register" style="text-align:center">Add new admin</a>
                    <a href="<?=ROOT?>/feed/profile" style="text-align:center">My Profile</a>
                    <a href="<?=ROOT?>/logout" style="text-align:center">Logout</a>
                </div>
            </div>        
        </div>
        <img class="img2" src="<?=ROOT?>/assets/images/acc.png">
        <img class="img3" src="<?=ROOT?>/assets/images/phone.png">
        <img class="img3" style="left:879px" src="<?=ROOT?>/assets/images/mail.png">
        <div class="name"><?=$first_name?>&nbsp;&nbsp;<?=$last_name?></div>
        <div class="info"><?=$contact_no?></div>
        <div class="info" style="left:900px"><?=$Admin_ID?></div>
        <?php echo '<a href="http://localhost/test_mvcEX/public/feed/edit"> <input type="submit" class="btn" value="Edit Profile"/></a>';?>
        

