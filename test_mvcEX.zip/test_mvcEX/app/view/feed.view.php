<html>
    <head>
        <title>Feed</title><link rel="Stylesheet" href="<?=ROOT?>/assets/css/feed.css">
        <script src="<?=ROOT?>/assets/js/feed.js"></script>
    </head>
    <body>
    <div>
        <div class="p2">
            <div><img class="logo"  src="<?=ROOT?>/assets/images/logo.png"></div>
            <div><img class="line3"  src="<?=ROOT?>/assets/images/line3.png"></div>
            <div><img class="square"  src="<?=ROOT?>/assets/images/square.png"></div>
            <div><button class="feed">Feed</button></div>
            <div><img class="Seller1"  src="<?=ROOT?>/assets/images/Seller1.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/seller"> <input type="submit" class="seller" value="Seller"/></a>';?>
            <div><img class="truck"  src="<?=ROOT?>/assets/images/truck.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/deliverer"> <input type="submit" class="deliverer" value="Deliverer"/></a>';?>
        </div>
        
        <div class="p3">
            <div class="user"><?=$username?></div>
            <div class="dropdown">
                <input type="image" class="img" src="<?=ROOT?>/assets/images/account.png">
                <div class="dropdown-content">
                    <a href="<?=ROOT?>/feed/register" style="text-align:center">Admin Registration</a>
                    <a href="<?=ROOT?>/feed/profile" style="text-align:center">My Profile</a>
                    <a style="text-align:center" class="log" onclick="openForm()">Logout</a>
                </div>
            </div>        
        </div>
            <div><button class="mrp">MRP</button></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/expired"> <input type="submit" class="expired" value="Expired"/></a>';?>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/soldout"> <input type="submit" class="soldout" value="Soldout"/></a>';?>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/stat"> <input type="submit" class="stat" value="Statistics"/></a>';?>
            <div class="p4">Manage Items</div>
            <form method="post">
            <div><input class="box" type="text" name="item_code" placeholder="Item Code"></div>
            <div><input class="box" style="left:701px" type="text" name="item_name" placeholder="Item Name"></div>
            <div><input class="box" style="left:880px" type="text" name="MRP" placeholder="MRP"></div>
            <div><button class="add" name="ADD">UPDATE</button></div>
            <div class="itc">Item Code</div>
            <div class="itc" style="left:709px">Item Name</div>
            <div class="itc" style="left:888px">MRP/KG</div>
            <div class="itn"><u>Item Code</div>
            <div class="itn" style="left:720px"><u>Item Name</div>
            <div class="itn" style="left:920px">MRP/KG</u></div>
            <div class="p1"><div class="p5">
                <?php foreach($data['a'] as $dat){ ?>
                    <div><?php echo($dat->item_code);  ?></div>
                    <div><?php echo($dat->item_name);  ?></div>
                    <div>Rs. <?php echo($dat->MRP);  ?></div>
                    <div><?php echo '<input type="image" class="img1" src="http://localhost/test_mvcEX/public/assets/images/delete.png" name="btn['.$dat->id.']/">' ?></div>
                    <div></div>
                <?php }
                ?>
            </div></div>
        </form>    
        </div>
    </div>
    
    <div class="form-popup" id="myForm" style="visibility:hidden">
            <h3 style="text-align: center;">Are you sure want to Log out ?</h3>
            <div><?php echo '<a href="http://localhost/test_mvcEX/public/logout"> <input type="submit" class="btn3" value="Yes"/></a>';?></div>
            <button type="button" style="left:135px" class="btn3" onclick="closeForm()">No</button>
    </div>
    </body>
</html>

