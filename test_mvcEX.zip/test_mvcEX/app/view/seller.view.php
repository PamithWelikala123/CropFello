<html>
    <head><title>Feed</title><link rel="Stylesheet" href="<?=ROOT?>/assets/css/seller.css"></head>
    <body>
    <div>
        <div class="p2">
            <div><img class="logo"  src="<?=ROOT?>/assets/images/logo.png"></div>
            <div><img class="line3"  src="<?=ROOT?>/assets/images/line3.png"></div>
            <div><img class="square"  src="<?=ROOT?>/assets/images/square.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed"> <input type="submit" class="feed" value="Feed"/></a>';?>
            <div><img class="Seller1"  src="<?=ROOT?>/assets/images/Seller1.png"></div>
            <div><button class="seller">Seller</button></div>
            <div><img class="truck"  src="<?=ROOT?>/assets/images/truck.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/deliverer"> <input type="submit" class="deliverer" value="Deliverer"/></a>';?>
        </div>
        <div class="p3"><img class="img" src="<?=ROOT?>/assets/images/account.png"></div>
        <div class="maxbox">
        <div class="rs">Reported Sellers</div>
        <div class="rs1"><u>Seller ID</div>
        <div class="rs1" style="left:264px"><u>Strike Count</div>
        <div class="rs1" style="left:882px">Reasons</u></div>
        <div class="box1">
            
            <div><center><b>Seller ID - <?php print_r($data['q3']);  ?></b></center></div>
            <br>
            <?php foreach($data['q2'] as $dat){ ?>
                    
                    <div><center><?php echo($dat->reason);  ?></center></div>
    
            <?php }
            ?>
            
        </div>
        <form method="post">
        <div class="box1" style="left:160px;width:510px;border:0px">
            <div class="box11">

            <?php foreach($data['q1'] as $dat){ ?>
                    <div><?php echo($dat->seller_id);  ?></div>
                    <div><?php echo($dat->count1);  ?></div>
                    <div><?php echo '<button class="check" name="check['.$dat->seller_id.']/">' ?>Check</button></div>
                    <div><?php echo '<button class="check" name="send['.$dat->seller_id.']/">' ?>Send</button></div>
                    <div><?php echo '<button class="strike" name="strike['.$dat->seller_id.']/">' ?>Ban</button></div>
                    
                <?php }
                ?>
            </div>
        </div>

        <div class="cost">Top Sellers</div>
        <div class="tab">
            <div class="tab1">
                <div style="font-size:20px"><b>Position</div><div style="font-size:20px">Seller ID</div><div style="font-size:20px">Email</b></div>
                <?php $i=1?>
                <?php foreach($data['q4'] as $dat){ ?>
                    <div><?php echo($i);  ?></div>
                    <div><?php echo($dat->seller_id);  ?></div>
                    <div><?php echo($dat->email);  ?></div>
                    <?php $i=$i+1?>
                <?php }
                ?>
            </div>
        </div>

            </div>
        </form>

        