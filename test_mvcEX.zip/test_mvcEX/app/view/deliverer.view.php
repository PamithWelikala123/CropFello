<html>
    <head><title>Feed</title><link rel="Stylesheet" href="<?=ROOT?>/assets/css/deliverer.css"></head>
    <body>
    <div>
        <div class="p2">
            <div><img class="logo"  src="<?=ROOT?>/assets/images/logo.png"></div>
            <div><img class="line3"  src="<?=ROOT?>/assets/images/line3.png"></div>
            <div><img class="square"  src="<?=ROOT?>/assets/images/square.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed"> <input type="submit" class="feed" value="Feed"/></a>';?>
            <div><img class="Seller1"  src="<?=ROOT?>/assets/images/Seller1.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/seller"> <input type="submit" class="seller" value="Seller"/></a>';?>
            <div><img class="truck"  src="<?=ROOT?>/assets/images/truck.png"></div>
            <div><button class="deliverer">Deliverer</button></div>
        </div>
        <div class="p3"><img class="img" src="<?=ROOT?>/assets/images/account.png"></div>
    <div class="maxbox">  
        
        <div class="cost" style="top:1300px;width:300px">Top Deliverers</div>    
        <div class="headd">Position</div><div class="headd" style="left:500px">Deliverer ID</div><div class="headd" style="left:750px">Name</div>  
        <div class="box69">
            <div class="gri1">
                <?php $i=1?>
                <?php foreach($data['q5'] as $dat){ ?>
                    <div><?php echo($i);  ?></div>
                    <div><?php echo($dat->deliverer_id);  ?></div>
                    <div><?php echo($dat->email);  ?></div>
                    <?php $i=$i+1?>
                <?php }
                ?>
            </div>
        </div> 

        <div class="rs">Reported Deliverers</div>
        <div class="rs1"><u>Deliverer ID</div>
        <div class="rs1" style="left:264px"><u>Strike Count</div>
        <div class="rs1" style="left:882px">Reasons</u></div>
        <div class="box1">
            <div><center><b>Deliverer ID - <?php print_r($data['q3'])?></b></center></div>
            <br>
            <?php foreach($data['q2'] as $dat){ ?>
                    
                    <div><center><?php echo($dat->reason);  ?></center></div>
    
            <?php }
            ?>

        </div>
        <form method="post">
        <div class="box1" style="left:160px;width:510px;border:0px">
            <div class="box11">
                <?php foreach($data['q1'] as $dat){ ?>
                    <div><?php echo($dat->deliverer_id);  ?></div>
                    <div><?php echo($dat->count1);  ?></div>
                    <div><?php echo '<button class="check" name="check['.$dat->deliverer_id.']/">' ?>Check</button></div>
                    <div><?php echo '<button class="check" name="send['.$dat->deliverer_id.']/">' ?>Send</button></div>
                    <div><?php echo '<button class="strike" name="strike['.$dat->deliverer_id.']/">' ?>Ban</button></div>
                <?php }
                ?>
            </div>
        </div>
        </form>
        <form method="post">
        <div class="cost">Cost per 1KM</div>
        <div class="vt">Vehicle type</div>
        <div class="vt" style="left:605px">Cost</div>
        <div><button class="update" name="update">Update</button></div>
        <div><input class="box2" type="text" name="name" placeholder="Vehicle type"></div>
        <div><input class="box2" style="left:598px;width:120px" type="text" name="cost" placeholder="Rs."></div>
        <div class="tab">
            <div class="tab1">
                <div style="font-size:20px">Vehicle Code</div><div style="font-size:20px">Vehicle Type</div><div style="font-size:20px">Cost/KM</div><div></div>
                <?php foreach($data['q4'] as $dat){ ?>
                    <div><?php echo($dat->id);  ?></div>
                    <div><?php echo($dat->name);  ?></div>
                    <div>Rs. <?php echo($dat->cost);  ?></div>
                    <div><?php echo '<input type="image" class="img1" src="http://localhost/test_mvcEX/public/assets/images/delete.png" name="btn['.$dat->id.']/">' ?></div>
                <?php }
                ?>
            </div>
        </div>
            
    </div>
            </div>

                