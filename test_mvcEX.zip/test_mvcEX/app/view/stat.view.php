<html>
    <head>
        <title>Feed</title><link rel="Stylesheet" href="<?=ROOT?>/assets/css/stat.css">
        <script src="<?=ROOT?>/assets/js/feed.js"></script>
    </head>
    <body>
    <div>
        <div class="p2">
            <div><img class="logo"  src="<?=ROOT?>/assets/images/logo.png"></div>
            <div><img class="line3"  src="<?=ROOT?>/assets/images/line3.png"></div>
            <div><img class="square"  src="<?=ROOT?>/assets/images/square.png"></div>
            <div><button class="feed">Feed</button></div>
            <div><img class="Seller1"  src="<?=ROOT?>/assets/images/Seller1.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/seller"> <input type="submit" class="seller" value="Seller"/></a>';?>
            <div><img class="truck"  src="<?=ROOT?>/assets/images/truck.png"></div>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/deliverer"> <input type="submit" class="deliverer" value="Deliverer"/></a>';?>
        </div>
        
        <div class="p3">
            <!--div class="user"><?=$username?></div-->
            <div class="dropdown">
                <input type="image" class="img" src="<?=ROOT?>/assets/images/account.png">
                <div class="dropdown-content">
                    <a href="<?=ROOT?>/feed/register" style="text-align:center">Admin Registration</a>
                    <a href="<?=ROOT?>/feed/profile" style="text-align:center">My Profile</a>
                    <a style="text-align:center" class="log" onclick="openForm()">Logout</a>
                </div>
            </div>        
        </div>
            <!--div><button class="mrp">MRP</button></div-->
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed"> <input type="submit" class="mrp" value="MRP"/></a>';?>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/expired"> <input type="submit" class="expired" value="Expired"/></a>';?>
            <?php echo '<a href="http://localhost/test_mvcEX/public/feed/soldout"> <input type="submit" class="soldout" value="Soldout"/></a>';?>
            <div><button class="stat">Statistics</button></div>
            <div class="box6">
                <div  class="head2">This Month</div>
                <div  class="head3">Ordinary Posts</div>
                <div  class="head3" style="left:672px">Bidding Posts</div>
                <div  class="most">Most Selling</div>
                <div class="most" style="font-size:20px;top:220px">Select Area</div>
                <div class="most" style="top:213px;left:240px">
                <form method="post">
                    <select name="color" id="color">
                        <option value="Island Wide"><?=$color?></option>
	                    <option value="Island Wide">Island Wide</option>
	                    <option value="ratnapura">ratnapura</option>
	                    <option value="galle">galle</option>
	                    <option value="colombo">colombo</option>
                    </select> 
                    <button name="ok" class="bttn">OK</button>
                </form>    
                </div>
                <div class="cl1">Position</div><div class="cl1" style="left:300px">Item ID</div><div class="cl1" style="left:500px">Crop</div>
                <div class="box7">
                    <div class="gri">
                        <?php $i=1?>
                        <?php foreach($data['a'] as $dat){ ?>
                        <div><?php echo($i)?></div>
                        <div><?php echo($dat->item_id);  ?></div>
                        <div><?php echo($dat->crop);  ?></div>
                        <?php $i=$i+1?>
                    <?php }
                    ?>
                    </div>
                </div>  
                <div class="most" style="top:650;width:300px">Most Uploading</div> 
                <div class="most" style="font-size:20px;top:720px">Select Area</div> 
                <div class="most" style="top:735px;left:240px">
                    <select name="color1" id="color1">
	                    <option value="">Island wide</option>
	                    <option value="red">Red</option>
	                    <option value="green">Green</option>
	                    <option value="blue">Blue</option>
                    </select>  
                </div>
                <div class="cl2">Position</div><div class="cl2" style="left:300px">Item ID</div><div class="cl2" style="left:500px">Crop</div>
                <div class="box8">
                <div class="gri">
                        <?php $i=1?>
                        <?php foreach($data['a'] as $dat){ ?>
                        <div><?php echo($i)?></div>
                        <div><?php echo($dat->item_id);  ?></div>
                        <div><?php echo($dat->crop);  ?></div>
                        <?php $i=$i+1?>
                    <?php }
                    ?>
                    </div>
                </div>
            </div>
            
            