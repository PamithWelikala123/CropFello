<html>
    <head>
        <title>Register</title>
        <link rel="Stylesheet" href="<?=ROOT?>/assets/css/register.css">
        <script src="<?=ROOT?>/assets/js/feed.js"></script>
    </head>
    <body>
    <img class="logo"  src="<?=ROOT?>/assets/images/logo.png">
    <div class="head">Admin <b>Registration</b></div>
    <form method="post">
        <?php if(!empty($errors)):?>
            <div class="form-popup" id="myForm" style="visibility:visible">
                <h3 style="text-align: center;"><?= implode("<br>",$errors)?></h3>
                <button type="button" style="left:135px" class="btn3" onclick="closeForm()">OK</button>
            </div>
            <?php endif;?>
        

        <div class="sub">First Name</div>
        <div class="sub" style="left:782px">Last Name</div>
        <div class="sub" style="top:407px">Email</div>
        <div class="sub" style="top:407px;left:782px">Password</div>
        <div class="sub" style="top:544px;left:782px;width:200px">Confirm Password</div>
        <div class="sub" style="top:544px;width:200px">Contact Number</div>
        <input type="textbox" class="box" name="first_name">
        <input type="textbox" style="left:776px" class="box" name="last_name">
        <input type="textbox" style="top:444px" class="box" name="Admin_ID">
        <input type="password" style="top:444px;left:776px" class="box" name="password">
        <input type="password" style="top:581px;left:778px" class="box" name="confirm_password">
        <input type="textbox" style="top:581px" class="box" name="contact_no">
        <input type="submit" class="btn" value="Register">
        <div><a href="<?=ROOT?>/feed" class="lin">Back</a></div>
    </form>
    </body>
</html>