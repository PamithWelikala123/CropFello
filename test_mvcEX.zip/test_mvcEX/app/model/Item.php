<?php

class Item{

    use Model;

    protected $table = 'items';
    protected $allowedColumns = ['item_code','item_name','MRP'];

    
}