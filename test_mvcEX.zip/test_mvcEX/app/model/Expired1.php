<?php

class Expired1{

    use Model;

    protected $table = 'expired';
    protected $allowedColumns = ['post_id','seller_id','exp','email'];

    public function email3($para2){
        $query = "select email from $this->table where id = $para2";
        return $this->query($query);
    }
}