<?php

class Seller1{

    use Model;

    protected $table = 'reported_sellers';
    protected $allowedColumns = ['buyer_id','seller_id','reason','id','email'];

    public function q1(){
       
        $query = "select seller_id, count(reason) as count1 from $this->table group by seller_id";
        return  $this->query($query);
    }

    public function q2($para1){
       
        $query = "select reason, seller_id from $this->table where seller_id = $para1";
        return  $this->query($query);
    }

    public function email2($para2){
        $query = "select distinct(email) from $this->table where seller_id = $para2";
        return $this->query($query);
    }

    public function del($para2){
        $query = "delete from $this->table where seller_id = $para2";
        return $this->query($query);
    }

    public function q3(){
       
        $query = "select seller_id, email, count(reason) as count1 from $this->table group by seller_id order by count1 limit 5";
        return  $this->query($query);
    }
}