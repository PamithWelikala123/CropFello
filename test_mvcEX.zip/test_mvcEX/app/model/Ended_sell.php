<?php

class Ended_sell{

    use Model;

    protected $table = 'ended_sell';
    protected $allowedColumns = ['id','item_id','crop','district'];

    public function f1(){
        $query = "select id,item_id, crop, count(crop) as count1 from $this->table group by crop order by count1 DESC limit 5";
        return  $this->query($query);
    }

    public function f2($para){
        $query = "select id,item_id, crop, count(crop) as count1 from $this->table where district = '$para' group by crop order by count1 DESC limit 5";
        return  $this->query($query);
    }

}