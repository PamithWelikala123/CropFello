<?php

class User{

    use Model;

    protected $table = 'users';
    protected $allowedColumns = ['Admin_ID','password','first_name','last_name','contact_no'];

    public function validate($data){

        $this->errors = [];
        if(empty($data['first_name'])){
            $this->errors['first_name'] = "Fields cannot be empty";
        }else if(empty($data['last_name'])){
            $this->errors['last_name'] = "Fields cannot be empty";
        }else if(empty($data['Admin_ID'])){
            $this->errors['Admin_ID'] = "Fields cannot be empty";
        }else if(!filter_var($data['Admin_ID'],FILTER_VALIDATE_EMAIL)){
            $this->errors['Admin_ID'] = "Email is not valid";
        }else if(empty($data['contact_no'])){
            $this->errors['contact_no'] = "Fields cannot be empty";
        }else if(empty($data['password'])){
            $this->errors['password'] = "Fields cannot be empty";
        }else if(strlen($data['password'] < 8)){
            $this->errors['password'] = "Password is not strong";
        }else if(empty($data['confirm_password'])){
            $this->errors['con_password'] = "Fields cannot be empty";
        }else if($data['password']!=$data['confirm_password']){
            $this->errors['match'] = "Passwords are not match";
        }

        if(empty($this->errors)){
            return true;
        }

        return false;
    }

    public function updat($id,$first,$last,$cont){
        $query = "update $this->table set first_name = $first, last_name = $last, contact_no = $cont where id = $id";
        return $this->query($query);
    }
    
}

