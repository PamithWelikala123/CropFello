<?php

class Vehicle{

    use Model;

    protected $table = 'vehicle';
    protected $allowedColumns = ['vehicle_code','name','cost'];

    
}