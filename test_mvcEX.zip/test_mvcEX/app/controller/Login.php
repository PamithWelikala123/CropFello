<?php

//login class
class Login{

    use Controller;
    public function index(){
        $data = [];
        if($_SERVER['REQUEST_METHOD'] == "POST"){

            $user = new User;
            $arr['Admin_ID'] = $_POST['Admin_ID']; 
            $row = $user->first($arr);

            if($row){
                if($row->password === md5($_POST['password'])){
                    $_SESSION['USER'] = $row;
                    redirect('feed');
                }
            }
            $user->errors['Admin_ID'] = "Wrong Admin ID or Password";
            $data['errors'] = $user->errors;
        }
        
        $this->view('login',$data);
        
    }
    
}