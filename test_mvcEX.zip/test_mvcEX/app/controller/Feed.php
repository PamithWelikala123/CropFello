<?php

//feed class
class Feed{

    use Controller;
    public function index(){

        $data['username'] = empty($_SESSION['USER']) ? 'User':$_SESSION['USER']->Admin_ID;
        
        if (isset($_POST['ADD'])){

            $item = new Item;
            $item->insert($_POST);
        }

        if (isset($_POST['btn'])){
            foreach($_POST['btn'] as $key => $value){
                $item = new Item;
                $item->delete($key);
            }	
        }
    
        if(isset($_POST['edit'])){
            foreach($_POST['edit'] as $key => $value){
                $item = new Item;
                $item->delete($key);
            }
        }

        $item = new Item;
        $data['a'] = $item->findAll();

        if(empty($data1)){
            $data1=[];
            $this->view('feed',$data);
        }else{
            $this->view('feed',$data);
        }
        
    }

    public function soldout(){
        $soldout = new Soldout1;
        
        //show($data);

        if (isset($_POST['btn'])) {
            foreach($_POST['btn'] as $key => $value){

              $soldout->delete($key);
              
            }	
        }

        if(isset($_POST['send'])){
            foreach($_POST['send'] as $key => $value){
                $re = $soldout->email3($key);
                del_email($re[0]->email); 
            }
        }

        $data = $soldout->findAll();

        if(empty($data)){
            $data = [];
            $this->view('soldout',$data);
        }else{
            $this->view('soldout',$data);
        }
    }

    public function expired(){
        $expired = new Expired1;

        if (isset($_POST['btn'])) {
            foreach($_POST['btn'] as $key => $value){
             
              $expired->delete($key);
              
            }	
        }

        if(isset($_POST['send'])){
            foreach($_POST['send'] as $key => $value){
                $re = $expired->email3($key);
                del_email($re[0]->email); 
            }
        }
        
        $data = $expired->findAll();

        if(empty($data)){
            $data = [];
            $this->view('expired',$data);
        }else{
            $this->view('expired',$data);
        }
    }

    public function seller(){
        $obj = new Seller1;
        
       

        if(isset($_POST['strike'])){
            foreach($_POST['strike'] as $key => $value){
                $obj1 = new Seller1;
                $obj1->del($key);
            }
        }

        $data['q1'] = $obj->q1();
        $data['q2'] = [];
        $data['q3'] = 0;

        if (isset($_POST['check'])){
            foreach($_POST['check'] as $key => $value){
                $data['q2'] = $obj->q2($key);
                $data['q3'] = $key;
            }	
        }

        if(isset($_POST['send'])){
            foreach($_POST['send'] as $key => $value){
                $re = $obj->email2($key);
                ban_email($re[0]->email); 
            }
        }

        $data['q4'] = $obj->q3();

        $this->view('seller',$data);
    }

    public function deliverer(){
        $obj = new Deliverer1;
        
        if(isset($_POST['strike'])){
            foreach($_POST['strike'] as $key => $value){
                $obj1 = new Deliverer1;
                $obj1->del($key);
            }
        }
        
        
        $data['q1'] = $obj->q1();
        $data['q2'] = [];
        $data['q3'] = 0;

        if (isset($_POST['check'])){
            foreach($_POST['check'] as $key => $value){
                $data['q2'] = $obj->q2($key);
                $data['q3'] = $key;
            }	
        }

        if(isset($_POST['send'])){
            foreach($_POST['send'] as $key => $value){
                $re = $obj->email2($key);
                ban_email($re[0]->email); 
            }
        }
        
        if (isset($_POST['update'])){

            $vehicle = new Vehicle;
            $vehicle->insert($_POST);
        }

        if (isset($_POST['btn'])){
            foreach($_POST['btn'] as $key => $value){
                $vehicle = new Vehicle;
                $vehicle->delete($key);
            }	
        }

        $vehicle = new Vehicle;
        $data['q4'] = $vehicle->findAll();
        $data['q5'] = $obj->q3();

        if(empty($data1)){
            $data1=[];
            $this->view('deliverer',$data);
        }else{
            $this->view('deliverer',$data);
        }
    }

    public function profile(){
        $data['first_name'] = empty($_SESSION['USER']) ? 'User':$_SESSION['USER']->first_name;
        $data['last_name'] = empty($_SESSION['USER']) ? 'User':$_SESSION['USER']->last_name;
        $data['Admin_ID'] = empty($_SESSION['USER']) ? 'User':$_SESSION['USER']->Admin_ID;
        $data['contact_no'] = empty($_SESSION['USER']) ? 'User':$_SESSION['USER']->contact_no;

        

        $this->view('profile',$data);
    }

    public function register(){
        $data = [];
        if($_SERVER['REQUEST_METHOD'] == "POST"){

            $user = new User;
            if($user->validate($_POST)){
                $_POST['password'] = md5($_POST['password']);
                $user->insert($_POST);
                redirect('feed');
            }
            $data['errors'] = $user->errors;
        }
        
        $this->view('register', $data);
    }

    public function stat(){

        $end = new Ended_sell;
        
        $data['a'] = $end->f1();
        $data['color'] = 'Island Wide';
        if(isset($_POST['ok'])){
            
            $color = filter_input(INPUT_POST, 'color', 513);

            if($color=='Island Wide'){
                $data['a'] = $end->f1();
            }else{
                $data['a'] = $end->f2($color);
            }
            //$end = new Ended_sell;
            $data['color'] = $color;
            $this->view('stat',$data);
        }else{
            $this->view('stat',$data);
        }
        

        
    }

    public function edit(){

        $data['username'] = empty($_SESSION['USER']) ? 'User':$_SESSION['USER']->Admin_ID;
        $this->view('edit',$data);
    }
}